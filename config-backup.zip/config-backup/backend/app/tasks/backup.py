"""
Backup tasks for Celery
"""
from datetime import datetime
from croniter import croniter
import logging

from app.celery_app import celery_app
from app.core.database import SessionLocal
from app.services.config_retriever import ConfigurationRetriever
from app.repositories.backup_job import BackupJobRepository
from app.repositories.device import DeviceRepository

logger = logging.getLogger(__name__)


@celery_app.task(bind=True, name="app.tasks.backup.backup_device_task", max_retries=3)
def backup_device_task(self, device_id: int, user_id: int = None):
    """
    Backup a single device configuration

    Args:
        device_id: Device ID to backup
        user_id: User ID triggering the backup (optional)

    Returns:
        dict: Backup result
    """
    logger.info(f"Starting backup task for device_id={device_id}")

    db = SessionLocal()
    try:
        retriever = ConfigurationRetriever(db)
        result = retriever.backup_device(device_id, user_id)

        if not result["success"]:
            logger.warning(f"Backup failed for device {device_id}: {result['message']}")

            # Retry on connection errors
            if "connection" in result["message"].lower() or "timeout" in result["message"].lower():
                logger.info(f"Retrying backup for device {device_id} (attempt {self.request.retries + 1}/3)")
                raise self.retry(exc=Exception(result["message"]), countdown=60)

        return result

    except Exception as e:
        logger.exception(f"Error in backup task for device {device_id}")
        return {
            "success": False,
            "device_id": device_id,
            "message": f"Task error: {str(e)}",
            "duration": 0,
        }

    finally:
        db.close()


@celery_app.task(name="app.tasks.backup.bulk_backup_task")
def bulk_backup_task(device_ids: list, user_id: int = None):
    """
    Backup multiple devices

    Args:
        device_ids: List of device IDs to backup
        user_id: User ID triggering the backup (optional)

    Returns:
        dict: Bulk backup result
    """
    logger.info(f"Starting bulk backup task for {len(device_ids)} devices")

    db = SessionLocal()
    try:
        retriever = ConfigurationRetriever(db)
        result = retriever.backup_multiple_devices(device_ids, user_id)

        logger.info(
            f"Bulk backup completed: {result['successful']}/{result['total']} successful"
        )

        return result

    except Exception as e:
        logger.exception(f"Error in bulk backup task")
        return {
            "total": len(device_ids),
            "successful": 0,
            "failed": len(device_ids),
            "error": str(e),
        }

    finally:
        db.close()


@celery_app.task(name="app.tasks.backup.scheduled_backup_task")
def scheduled_backup_task(job_id: int):
    """
    Execute a scheduled backup job

    Args:
        job_id: Backup job ID

    Returns:
        dict: Job execution result
    """
    logger.info(f"Executing scheduled backup job {job_id}")

    db = SessionLocal()
    try:
        job_repo = BackupJobRepository(db)
        device_repo = DeviceRepository(db)
        retriever = ConfigurationRetriever(db)

        # Get the job
        job = job_repo.get(job_id)
        if not job:
            logger.error(f"Backup job {job_id} not found")
            return {
                "success": False,
                "message": f"Job {job_id} not found",
            }

        if not job.is_enabled:
            logger.warning(f"Backup job {job_id} is disabled, skipping")
            return {
                "success": False,
                "message": "Job is disabled",
            }

        # Get devices to backup based on job filter
        if job.device_filter:
            # Apply filters from job configuration
            # For now, backup all active devices in the organization
            # Can be enhanced to support complex filtering
            devices = device_repo.get_active_by_organization(job.organization_id)
        else:
            # No filter, backup all active devices
            devices = device_repo.get_active_by_organization(job.organization_id)

        if not devices:
            logger.warning(f"No devices found for job {job_id}")
            return {
                "success": True,
                "message": "No devices to backup",
                "devices_backed_up": 0,
            }

        # Backup all devices
        device_ids = [d.id for d in devices]
        logger.info(f"Job {job_id}: backing up {len(device_ids)} devices")

        result = retriever.backup_multiple_devices(device_ids, user_id=None)

        # Update job's last run and calculate next run
        current_time = datetime.utcnow()
        try:
            cron = croniter(job.schedule_cron, current_time)
            next_run = cron.get_next(datetime)
        except Exception as e:
            logger.error(f"Error calculating next run for job {job_id}: {e}")
            next_run = None

        job_repo.update_last_run(job_id, current_time, next_run)

        logger.info(
            f"Scheduled job {job_id} completed: "
            f"{result['successful']}/{result['total']} successful"
        )

        return {
            "success": True,
            "job_id": job_id,
            "devices_backed_up": result["successful"],
            "devices_failed": result["failed"],
            "next_run": next_run.isoformat() if next_run else None,
        }

    except Exception as e:
        logger.exception(f"Error executing scheduled backup job {job_id}")
        return {
            "success": False,
            "job_id": job_id,
            "error": str(e),
        }

    finally:
        db.close()


@celery_app.task(name="app.tasks.backup.apply_retention_policy_task")
def apply_retention_policy_task(device_id: int, keep_count: int = None):
    """
    Apply retention policy to a device's configurations

    Args:
        device_id: Device ID
        keep_count: Number of configurations to keep (optional)

    Returns:
        dict: Retention policy result
    """
    logger.info(f"Applying retention policy to device {device_id}")

    db = SessionLocal()
    try:
        retriever = ConfigurationRetriever(db)
        deleted_count = retriever.apply_retention_policy(device_id, keep_count)

        logger.info(f"Retention policy applied to device {device_id}: {deleted_count} configs deleted")

        return {
            "success": True,
            "device_id": device_id,
            "deleted_count": deleted_count,
        }

    except Exception as e:
        logger.exception(f"Error applying retention policy to device {device_id}")
        return {
            "success": False,
            "device_id": device_id,
            "error": str(e),
        }

    finally:
        db.close()


@celery_app.task(name="app.tasks.backup.check_scheduled_jobs_task")
def check_scheduled_jobs_task():
    """
    Check for scheduled backup jobs that are due to run

    This task is triggered periodically by Celery Beat (every minute)
    and executes any jobs that are scheduled to run.

    Returns:
        dict: Summary of jobs checked and triggered
    """
    logger.info("Checking for scheduled backup jobs")

    db = SessionLocal()
    try:
        job_repo = BackupJobRepository(db)
        current_time = datetime.utcnow()

        # Get jobs that are due
        due_jobs = job_repo.get_jobs_due(current_time)

        if not due_jobs:
            logger.debug("No scheduled jobs due at this time")
            return {
                "success": True,
                "jobs_checked": 0,
                "jobs_triggered": 0,
            }

        logger.info(f"Found {len(due_jobs)} job(s) due for execution")

        triggered_count = 0
        for job in due_jobs:
            try:
                # Trigger the scheduled backup task
                task = scheduled_backup_task.delay(job.id)
                logger.info(
                    f"Triggered job '{job.name}' (ID: {job.id}, Task: {task.id})"
                )
                triggered_count += 1

            except Exception as e:
                logger.error(f"Failed to trigger job {job.id}: {e}")

        return {
            "success": True,
            "jobs_checked": len(due_jobs),
            "jobs_triggered": triggered_count,
            "timestamp": current_time.isoformat(),
        }

    except Exception as e:
        logger.exception("Error checking scheduled jobs")
        return {
            "success": False,
            "error": str(e),
        }

    finally:
        db.close()
